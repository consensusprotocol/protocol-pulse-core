#!/usr/bin/env python3
"""Master orchestrator for Pulse Check video pipeline — V5 real content.

# Cron: 0 12 * * * python3 -c 'from core.services.newsletter import NewsletterEngine; NewsletterEngine().send()'
# (12 UTC = 08:00 ET — B1 Newsletter daily send)
"""
import os, sys, json, argparse, time, shutil
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)

from channel_scanner import scan_all_channels
from clip_selector import select_clips
from clip_extractor import extract_all as extract_clips
from script_writer import generate_from_clips, generate_script
from tts_engine import generate_all_audio
from clip_fetcher import fetch_all_clips
from assembler import assemble_episode, verify_video
from shorts_cutter import generate_shorts


def _load_cached_transcripts() -> list:
    """Load videos from cached transcript files (skip scan + transcription)."""
    transcript_dir = os.path.join(BASE, "transcripts")
    videos = []
    if not os.path.isdir(transcript_dir):
        return videos
    for fname in os.listdir(transcript_dir):
        if not fname.endswith(".json"):
            continue
        try:
            with open(os.path.join(transcript_dir, fname)) as f:
                data = json.load(f)
            vid = fname.replace(".json", "")
            videos.append({
                "video_id": vid,
                "title": data.get("title", vid),
                "channel": data.get("channel", "Unknown"),
                "duration": data.get("duration", 0),
                "upload_date": "",
                "url": f"https://www.youtube.com/watch?v={vid}",
                "transcript_text": data.get("text", ""),
                "timestamped_text": data.get("timestamped_text", ""),
            })
        except Exception:
            continue
    return videos


def run_pipeline(output_path: str, style: str = "default", cached_only: bool = False) -> bool:
    """Run the complete V5 video pipeline with real content."""
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = os.path.join(BASE, "output", f"run_{run_id}")
    os.makedirs(run_dir, exist_ok=True)

    print("\n" + "=" * 70)
    print(f"  PULSE CHECK V5 PIPELINE — Run {run_id}")
    print(f"  Style: {style}")
    print(f"  Output: {output_path}")
    if cached_only:
        print(f"  Mode: CACHED TRANSCRIPTS ONLY (skip scan)")
    print("=" * 70)

    # ─── Step 0: Narrative Intelligence (thought leader X monitoring) ───
    print("\n[STEP 0/8] NARRATIVE INTELLIGENCE — THOUGHT LEADER MONITORING...")
    t0 = time.time()
    try:
        from utils.narrative_intelligence import NarrativeIntelligenceEngine
        ni_engine = NarrativeIntelligenceEngine()
        narrative_result = ni_engine.run()
        dominant = narrative_result.get("dominant_narrative", "unknown")
        mood = narrative_result.get("market_mood", "unknown")
        top_topics = [t["topic"] for t in narrative_result.get("topic_velocity", [])[:3]]
        print(f"  Dominant narrative: {dominant}")
        print(f"  Market mood: {mood}")
        print(f"  Top topics: {', '.join(top_topics)}")
        print(f"  Thought leaders active: {narrative_result.get('thought_leaders_active', 0)}")
        print(f"  Time: {time.time()-t0:.1f}s")
    except Exception as e:
        print(f"  [WARN] Narrative intelligence unavailable: {e} — continuing with historical signals")

    # ─── Step 0b: Load Morning Intelligence Brief ───
    morning_brief = None
    brief_path = os.path.join(os.path.dirname(BASE), "data", "intelligence", "morning_intelligence_brief.json")
    if os.path.exists(brief_path):
        try:
            with open(brief_path) as f:
                morning_brief = json.load(f)
            print(f"  Morning brief loaded: {morning_brief.get('date', 'unknown')}")
            print(f"  Dominant narratives: {len(morning_brief.get('dominant_narratives', []))}")
            print(f"  Trending language: {len(morning_brief.get('trending_language', []))}")
            print(f"  Tweet angles: {len(morning_brief.get('recommended_tweet_angles', []))}")
        except Exception as e:
            print(f"  [WARN] Morning brief load failed: {e}")
    else:
        print("  Morning brief not found — continuing without it")

    # ─── BTC Price (fetch early, used everywhere) ───
    btc_price = "N/A"
    try:
        import urllib.request as _ur
        with _ur.urlopen("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd", timeout=5) as r:
            _cg_usd = json.loads(r.read())['bitcoin']['usd']
            if _cg_usd and _cg_usd > 0:
                btc_price = f"${_cg_usd:,.0f}"
    except Exception:
        pass
    if btc_price == "N/A":
        try:
            import urllib.request as _ur
            with _ur.urlopen("https://mempool.space/api/v1/prices", timeout=5) as r:
                _mp_usd = json.loads(r.read()).get('USD', 0)
                if _mp_usd and _mp_usd > 0:
                    btc_price = f"${_mp_usd:,.0f}"
        except Exception:
            pass
    print(f"  BTC Price: {btc_price}")

    # ─── Step 1: Scan channels + transcribe ───
    if cached_only:
        print("\n[STEP 1/7] LOADING CACHED TRANSCRIPTS...")
        t0 = time.time()
        videos = _load_cached_transcripts()
    else:
        print("\n[STEP 1/7] SCANNING BITCOIN YOUTUBE CHANNELS...")
        t0 = time.time()
        videos = scan_all_channels()
    print(f"  Videos scanned: {len(videos)}")
    print(f"  With transcripts: {sum(1 for v in videos if v.get('transcript_text'))}")
    print(f"  Time: {time.time()-t0:.1f}s")

    if not videos or not any(v.get('transcript_text') for v in videos):
        print("  [WARN] No transcripts — falling back to legacy script")
        script = generate_script(style=style)
        selections = {}
        extracted_clips = {}
    else:
        # ─── Step 2: Select best clips ───
        print("\n[STEP 2/6] SELECTING BEST CLIPS (Claude EP)...")
        t0 = time.time()
        selections = select_clips(videos)
        clips = selections.get("clips", [])
        print(f"  Clips selected: {len(clips)}")
        for i, c in enumerate(clips, 1):
            print(f"    {i}. {c.get('channel','?')} — {c.get('video_title', c.get('title','?'))[:60]}")
        print(f"  Time: {time.time()-t0:.1f}s")

        if not clips:
            print("  [WARN] No clips selected — falling back")
            script = generate_script(style=style)
            extracted_clips = {}
        else:
            # ─── Step 2b: Extract clip segments from YouTube ───
            print("\n[STEP 2b/7] EXTRACTING CLIP SEGMENTS (yt-dlp + ffmpeg)...")
            t0 = time.time()
            yt_clip_dir = os.path.join(run_dir, "yt_clips")
            extracted_clips = extract_clips(selections, yt_clip_dir)
            print(f"  Clips extracted: {len(extracted_clips)}")
            for rank, ci in sorted(extracted_clips.items()):
                print(f"    #{rank}: {ci.get('channel','?')} — {ci.get('duration',0):.1f}s")
            print(f"  Time: {time.time()-t0:.1f}s")

            # ─── Step 3: Generate script from clips ───
            print("\n[STEP 3/7] WRITING HOST DIALOGUE...")
            t0 = time.time()
            script = generate_from_clips(selections, btc_price=btc_price,
                                                morning_brief=morning_brief)
            # Carry space_tap_clips into script for assembler
            if selections.get('space_tap_clips'):
                script['space_tap_clips'] = selections['space_tap_clips']
            seg_count = len(script.get("segments", []))
            word_count = sum(len(s.get("text", "").split()) for s in script.get("segments", []))
            print(f"  Segments: {seg_count}")
            print(f"  Words: {word_count}")
            print(f"  Title: {script.get('episode_title', '?')}")
            print(f"  Time: {time.time()-t0:.1f}s")

    # Save script
    with open(os.path.join(run_dir, "script.json"), "w") as f:
        json.dump(script, f, indent=2)

    # ─── Step 3b: Space Tap clip discovery (runs regardless of cached_only) ───
    try:
        sys.path.insert(0, os.path.join(BASE, '..', 'x_spaces_scraper'))
        from scraper import get_best_space_clips
        _st_data = get_best_space_clips(max_clips=4)
        if _st_data and _st_data.get('clips'):
            selections['space_tap_clips'] = _st_data['clips']
            script['space_tap_clips'] = _st_data['clips']
            with open(os.path.join(run_dir, "script.json"), "w") as f:
                json.dump(script, f, indent=2)
            print(f"  Space Tap: injected {len(_st_data['clips'])} clips into script")
        else:
            print("  Space Tap: no clips available — segment skipped")
    except Exception as e:
        print(f"  Space Tap: skipped ({e})")

    # ─── Step 4: TTS ───
    print("\n[STEP 4/7] GENERATING TTS AUDIO (ElevenLabs)...")
    t0 = time.time()
    audio_dir = os.path.join(run_dir, "audio")
    audio_paths = generate_all_audio(script, audio_dir)
    seg_count = sum(1 for s in audio_paths.get("segments", []) if s and os.path.exists(s))
    print(f"  Audio segments: {seg_count}")
    print(f"  Time: {time.time()-t0:.1f}s")

    # ─── Step 5: Fetch B-roll ───
    print("\n[STEP 5/7] FETCHING B-ROLL CLIPS...")
    t0 = time.time()
    clip_dir = os.path.join(run_dir, "clips")
    clip_data = fetch_all_clips(script, clip_dir)
    # Merge any yt_clips from fetcher (legacy path) into extracted_clips
    for rk, ci in clip_data.get("yt_clips", {}).items():
        try: rank = int(rk)
        except: rank = len(extracted_clips) + 1
        if rank not in extracted_clips:
            if isinstance(ci, list): ci = ci[0] if ci and isinstance(ci[0], dict) else {"path": ""}
            if isinstance(ci, dict): extracted_clips[rank] = ci
    print(f"  YouTube clips (total): {len(extracted_clips)}")
    print(f"  Pexels B-roll: {len(clip_data.get('broll', []))}")
    print(f"  Time: {time.time()-t0:.1f}s")

    # ─── Step 5b: X Spaces Segment Injection ───
    try:
        from utils.spaces_pipeline import get_latest_spaces_segment
        spaces_seg = get_latest_spaces_segment(max_age_hours=6)
        if spaces_seg:
            segments = script.get("segments", [])
            # Insert before last segment (wrap/outro)
            if segments:
                segments.insert(-1, spaces_seg)
            else:
                segments.append(spaces_seg)
            script["segments"] = segments
            print(f"  X Spaces segment injected: {spaces_seg['space_title']}")
        else:
            print("  No fresh X Spaces content — skipping injection")
    except Exception as e:
        print(f"  X Spaces injection skipped: {e}")

    # ─── Step 6: Assemble ───
    print("\n[STEP 6/7] ASSEMBLING VIDEO (assembler_v2)...")
    t0 = time.time()
    broll_clips = clip_data.get("broll", [])
    try:
        import sys as _sys
        _sys.path.insert(0, BASE)
        from assembler_v2.daily_bridge import build_manifest_from_pipeline
        from assembler_v2.episode import EpisodeRunner
        from pathlib import Path as _Path

        date_str = datetime.now().strftime("%Y-%m-%d")
        manifest = build_manifest_from_pipeline(
            script=script,
            audio_paths=audio_paths,
            extracted_clips=extracted_clips,
            btc_price=btc_price,
            date_str=date_str,
            audio_dir=audio_dir,
        )

        output_dir = _Path(os.path.dirname(output_path))
        output_dir.mkdir(parents=True, exist_ok=True)

        runner = EpisodeRunner()
        report = runner.run(manifest, output_dir)

        print(f"  Verdict: {report.verdict}")
        print(f"  Segments: {len(report.segment_reports)}")
        print(f"  Degraded: {report.degraded_count}")
        print(f"  Filler: {report.total_filler_seconds:.1f}s")
        print(f"  Duration: {report.duration:.1f}s")
        print(f"  Time: {time.time()-t0:.1f}s")

        if report.verdict == "HOLD":
            print(f"  [HOLD] Episode held: {report.error}")
            result = False
        else:
            # Copy final output to expected output_path
            if report.output_path and report.output_path.exists():
                import shutil as _shutil
                _shutil.copy2(str(report.output_path), output_path)
                result = True
            else:
                print("  [FAIL] No output file produced")
                result = False

    except Exception as e:
        print(f"  [WARN] assembler_v2 failed: {e} — falling back to legacy assembler")
        import traceback; traceback.print_exc()
        result = assemble_episode(script, audio_paths, extracted_clips, output_path,
                                  btc_price=btc_price, broll_clips=broll_clips)

    print(f"  Time: {time.time()-t0:.1f}s")

    if not result:
        print("\n  [FAIL] Assembly failed!")
        return False

    # ─── Step 7: Verify ───
    print("\n[STEP 7/7] VERIFYING OUTPUT...")
    passed = verify_video(output_path)

    # ─── Generate Shorts ───
    work_dir = os.path.join(os.path.dirname(output_path), "work")
    shorts_dir = os.path.join(BASE, "output", "shorts")
    print("\n[BONUS] GENERATING VERTICAL SHORTS...")
    shorts = generate_shorts(script, shorts_dir)
    print(f"  Shorts generated: {len(shorts)}")

    # ─── Export tweet angles from morning brief for auto-tweet machine ───
    if morning_brief and morning_brief.get("recommended_tweet_angles"):
        tweet_angles_path = os.path.join(os.path.dirname(BASE), "data", "social_queue",
                                          f"{datetime.now().strftime('%Y%m%d')}_brief_angles.json")
        try:
            os.makedirs(os.path.dirname(tweet_angles_path), exist_ok=True)
            with open(tweet_angles_path, "w") as f:
                json.dump({
                    "source": "morning_intelligence_brief",
                    "generated_at": morning_brief.get("generated_at", ""),
                    "angles": morning_brief["recommended_tweet_angles"],
                    "trending_language": morning_brief.get("trending_language", []),
                }, f, indent=2)
            print(f"  Tweet angles exported: {tweet_angles_path}")
        except Exception as e:
            print(f"  [WARN] Tweet angles export failed: {e}")

    # Summary
    print("\n" + "=" * 70)
    if passed:
        print(f"  SUCCESS: {output_path}")
        try:
            import subprocess
            r = subprocess.run(
                f"ffprobe -v error -show_entries format=duration,size -of csv=p=0 '{output_path}'",
                shell=True, capture_output=True, text=True
            )
            parts = r.stdout.strip().split(",")
            dur = float(parts[0]) if parts else 0
            sz = int(parts[1]) if len(parts) > 1 else 0
            print(f"  Duration: {dur:.1f}s | Size: {sz/1024/1024:.1f}MB")
        except:
            pass
    else:
        print(f"  WARNING: Verification had failures, but video may still be usable")
    print("=" * 70)

    return passed


def main():
    parser = argparse.ArgumentParser(description="Pulse Check Video Pipeline")
    parser.add_argument("--output", "-o", default=None, help="Output MP4 path")
    parser.add_argument("--style", "-s", default="default", choices=["default", "breaking"],
                        help="Script style")
    parser.add_argument("--date", default="today", help="Date for content (unused in V1)")
    parser.add_argument("--cached-only", action="store_true",
                        help="Use cached transcripts only (skip channel scan + Whisper)")
    args = parser.parse_args()

    if args.output is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        args.output = os.path.join(BASE, "output", f"pulse_check_{ts}.mp4")

    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    success = run_pipeline(args.output, args.style, cached_only=args.cached_only)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
