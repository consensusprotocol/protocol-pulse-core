#!/usr/bin/env python3
"""
gemini_grade.py — Protocol Pulse V6 Quality Gate
Submits full forensic data to Gemini 2.5 Pro for rigorous grading.
Only exits 0 (PASS) if grade == A and broadcast_ready == True.
PBX sees NOTHING until this exits 0.
"""
import os, sys, json, urllib.request, subprocess, re, time
from pathlib import Path

# Derive all paths from this file's location (audit P1-3)
BASE_DIR = Path(__file__).resolve().parent.parent
PIPELINE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / '.env'
LOG = str(PIPELINE_DIR / 'logs' / 'grade_report.log')
GRADE_FILE = str(PIPELINE_DIR / 'logs' / 'v6_gemini_grade.json')
PASS_FILE = str(PIPELINE_DIR / 'logs' / 'v6_grade_PASS.txt')
OUTPUT_DIR = str(PIPELINE_DIR / 'output')
GRADES_DIR = str(PIPELINE_DIR / 'logs' / 'grades')


def upload_video_to_gemini(video_path, gemini_key):
    """Upload video file to Gemini Files API. Returns file URI or None."""
    import mimetypes
    file_size = os.path.getsize(video_path)
    log(f"Uploading {file_size/1048576:.1f}MB video to Gemini Files API...")

    # Resumable upload initiation
    init_url = f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={gemini_key}"
    mime = "video/mp4"
    init_headers = {
        "Content-Type": "application/json",
        "X-Goog-Upload-Protocol": "resumable",
        "X-Goog-Upload-Command": "start",
        "X-Goog-Upload-Header-Content-Type": mime,
        "X-Goog-Upload-Header-Content-Length": str(file_size),
    }
    init_body = json.dumps({"file": {"display_name": os.path.basename(video_path)}}).encode()

    try:
        init_req = urllib.request.Request(init_url, data=init_body, headers=init_headers, method="POST")
        with urllib.request.urlopen(init_req, timeout=30) as r:
            upload_url = r.headers.get("X-Goog-Upload-URL")
        if not upload_url:
            log("Upload init failed — no upload URL returned")
            return None

        # Upload file bytes
        with open(video_path, "rb") as f:
            video_bytes = f.read()

        upload_headers = {
            "Content-Length": str(file_size),
            "X-Goog-Upload-Offset": "0",
            "X-Goog-Upload-Command": "upload, finalize",
        }
        upload_req = urllib.request.Request(upload_url, data=video_bytes, headers=upload_headers, method="PUT")
        with urllib.request.urlopen(upload_req, timeout=120) as r:
            result = json.loads(r.read())
            file_uri = result.get("file", {}).get("uri")
            file_name = result.get("file", {}).get("name", "")
            log(f"Video uploaded: {file_uri}")

        # Poll until file is ACTIVE (Gemini processes video after upload)
        if file_name:
            status_url = f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={gemini_key}"
            for attempt in range(30):  # up to ~150s wait
                time.sleep(5)
                try:
                    status_req = urllib.request.Request(status_url, method="GET")
                    with urllib.request.urlopen(status_req, timeout=15) as sr:
                        status_data = json.loads(sr.read())
                        state = status_data.get("state", "UNKNOWN")
                        if state == "ACTIVE":
                            log(f"File ready (ACTIVE) after {(attempt+1)*5}s")
                            break
                        log(f"File state: {state} — waiting... ({(attempt+1)*5}s)")
                except Exception as poll_err:
                    log(f"Status poll error: {poll_err}")
            else:
                log("File never became ACTIVE after 150s — falling back to text-only")
                return None

        return file_uri
    except Exception as e:
        log(f"Video upload failed: {e} — falling back to text-only grading")
        return None


def load_env():
    """Load .env file with error handling (audit P1-2)."""
    try:
        with open(ENV_PATH) as f:
            for line in f:
                l = line.strip()
                if '=' in l and not l.startswith('#'):
                    k, _, v = l.partition('=')
                    k = k.strip(); v = v.strip().strip("'").strip('"')
                    if k: os.environ[k] = v
    except FileNotFoundError:
        print(f"FATAL: .env not found at {ENV_PATH}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"FATAL: .env load error: {e}", file=sys.stderr)
        sys.exit(1)


def log(msg):
    ts = time.strftime('%Y-%m-%d %H:%M:%S')
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG, 'a') as f:
            f.write(line + '\n')
    except Exception:
        pass


def run(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return r.stdout.strip()


def find_latest_output(cli_path=None):
    """Find the latest pulse_check MP4 output file."""
    if cli_path and os.path.isfile(cli_path):
        return cli_path

    candidates = []
    for root, dirs, files in os.walk(OUTPUT_DIR):
        for f in files:
            if (f.endswith('.mp4') and 'pulse_check' in f and '.mp4.' not in os.path.basename(f)
                    and 'bgl_audio' not in f and 'archived' not in f
                    and 'music_mixed' not in f and 'concat_raw' not in f and 'norm' not in f):
                full = os.path.join(root, f)
                candidates.append((os.path.getmtime(full), full))

    candidates.sort(reverse=True)
    return candidates[0][1] if candidates else None


def main():
    load_env()
    GEMINI_KEY = os.environ.get('GEMINI_API_KEY', '')
    RENDER_LOG = None

    # Allow CLI argument for explicit video path
    cli_path = sys.argv[1] if len(sys.argv) > 1 else None
    LATEST = find_latest_output(cli_path)

    if not LATEST:
        log("FATAL: No MP4 output found")
        sys.exit(2)

    log(f"Grading: {LATEST}")

    # ── ffprobe ───────────────────────────────────────────────────────
    log("Running ffprobe...")
    probe_raw = run(f'ffprobe -v quiet -print_format json -show_format -show_streams "{LATEST}"')
    try:
        probe = json.loads(probe_raw)
        fmt = probe.get('format', {})
        streams = probe.get('streams', [])
        duration = float(fmt.get('duration', 0))
        filesize_mb = int(fmt.get('size', 0)) / 1048576
        v_stream = next((s for s in streams if s.get('codec_type') == 'video'), {})
        a_stream = next((s for s in streams if s.get('codec_type') == 'audio'), {})
        width = v_stream.get('width', 0)
        height = v_stream.get('height', 0)
        vcodec = v_stream.get('codec_name', 'unknown')
        fps_raw = v_stream.get('r_frame_rate', '0/1')
        fps_num, fps_den = fps_raw.split('/') if '/' in fps_raw else (fps_raw, '1')
        fps = round(int(fps_num) / max(int(fps_den), 1), 2)
        acodec = a_stream.get('codec_name', 'unknown')
        sample_rate = a_stream.get('sample_rate', '?')
        channels = a_stream.get('channel_layout', '?')
        num_streams = len(streams)
        bit_rate_kbps = round(int(fmt.get('bit_rate', 0)) / 1000)
    except Exception as e:
        log(f"ffprobe parse error: {e}")
        duration = filesize_mb = 0
        width = height = fps = 0
        vcodec = acodec = 'unknown'
        sample_rate = channels = '?'
        num_streams = 0
        bit_rate_kbps = 0

    log(f"Duration: {duration:.1f}s | Size: {filesize_mb:.1f}MB | {width}x{height} @ {fps}fps | {vcodec}/{acodec}")

    # ── Black frame detection ─────────────────────────────────────────
    log("Running blackdetect...")
    black_raw = run(f'ffmpeg -i "{LATEST}" -vf "blackdetect=d=0.3:pix_th=0.10" -an -f null - 2>&1 | grep black_')
    black_segments = re.findall(r'black_start:([\d.]+).*?black_end:([\d.]+).*?black_duration:([\d.]+)', black_raw)
    black_mid = [(s,e,d) for s,e,d in black_segments
                 if float(s) > 2.0 and float(e) < duration - 2.0]
    black_count_total = len(black_segments)
    black_count_mid = len(black_mid)
    log(f"Black segments: {black_count_total} total, {black_count_mid} mid-video (problem ones)")

    # ── Silence detection ─────────────────────────────────────────────
    log("Running silencedetect...")
    silence_raw = run(f'ffmpeg -i "{LATEST}" -af "silencedetect=noise=-45dB:d=0.8" -f null - 2>&1 | grep silence_')
    silence_starts = re.findall(r'silence_start: ([\d.]+)', silence_raw)
    silence_ends = re.findall(r'silence_end: ([\d.]+)', silence_raw)
    silence_mid = [float(s) for s in silence_starts if float(s) > 2.0 and float(s) < duration - 2.0]
    # Section 2f: Exclude short silence gaps under 4s (likely dramatic pauses from "..." in script)
    # Only count genuine dead air — pair starts with ends to measure duration
    _silence_with_dur = []
    for _ss, _se in zip(silence_starts, silence_ends):
        _ss_f, _se_f = float(_ss), float(_se)
        if _ss_f > 2.0 and _ss_f < duration - 2.0:
            _silence_with_dur.append((_ss_f, _se_f - _ss_f))
    # Keep only gaps >= 4s as genuine dead air (shorter ones may be dramatic pauses)
    silence_genuine = [s for s, d in _silence_with_dur if d >= 4.0]
    silence_count = len(silence_genuine)
    log(f"Silence gaps mid-video: {len(silence_mid)} raw, {silence_count} genuine (excl pauses <4s)")

    # ── EBU R128 loudness ─────────────────────────────────────────────
    log("Running EBU R128 loudness measurement...")
    loudness_raw = run(f'ffmpeg -i "{LATEST}" -map 0:a -af "ebur128=peak=true" -f null - 2>&1')
    integrated_match = re.search(r'^\s+I:\s+(-[\d.]+)\s+LUFS', loudness_raw, re.MULTILINE)
    true_peak_match = re.search(r'^\s+Peak:\s+(-?[\d.]+)\s+dBFS', loudness_raw, re.MULTILINE)
    lra_match = re.search(r'^\s+LRA:\s+([\d.]+)\s+LU', loudness_raw, re.MULTILINE)
    integrated_lufs = float(integrated_match.group(1)) if integrated_match else None
    true_peak_dbfs = float(true_peak_match.group(1)) if true_peak_match else None
    lra_lu = float(lra_match.group(1)) if lra_match else None
    log(f"Loudness: {integrated_lufs} LUFS | True Peak: {true_peak_dbfs} dBFS | LRA: {lra_lu} LU")

    # ── Freeze frame detection ────────────────────────────────────────
    log("Running freezedetect...")
    # FIX: freeze threshold n=0.003 (was 0.001, then 0.02 — 0.003 balances sensitivity)
    freeze_raw = run(f'ffmpeg -i "{LATEST}" -vf "freezedetect=n=0.003:d=1.0" -an -f null - 2>&1 | grep freeze')
    _freeze_events = []
    _freeze_starts = re.findall(r'freeze_start:\s*([\d.]+)', freeze_raw)
    _freeze_durs   = re.findall(r'freeze_duration:\s*([\d.]+)', freeze_raw)
    for s, d in zip(_freeze_starts, _freeze_durs):
        _freeze_events.append((float(s), float(d)))

    _vid_dur = 0
    try:
        _vid_dur_raw = run(f'ffprobe -v error -show_entries format=duration '
                           f'-of default=noprint_wrappers=1:nokey=1 "{LATEST}"')
        _vid_dur = float(_vid_dur_raw) if _vid_dur_raw else 0
    except Exception:
        _vid_dur = 0

    _outro_start = max(0, _vid_dur - 25)
    freeze_count = sum(
        1 for (s, d) in _freeze_events
        if d > 2.0 and s > 16.0 and s < _outro_start
    )
    log(f"Freeze events: {len(_freeze_events)} total, "
        f"{freeze_count} penalized (excl intro <16s, outro >{_outro_start:.0f}s)")

    # ── Audio/video stream count ──────────────────────────────────────
    has_video = v_stream != {}
    has_audio = a_stream != {}

    # ── Read render log for content context ──────────────────────────
    render_log_content = ''
    try:
        import glob as _glob
        _log_dir = str(PIPELINE_DIR / 'logs')
        _candidates = (_glob.glob(f'{_log_dir}/render_*.log') +
                       _glob.glob(f'{_log_dir}/full_render_*.log') +
                       _glob.glob(f'{_log_dir}/v6_render.log'))
        _candidates = [f for f in _candidates if os.path.isfile(f)]
        _fresh_cutoff = time.time() - 7200
        _candidates = [f for f in _candidates if os.path.getmtime(f) >= _fresh_cutoff]
        if _candidates:
            RENDER_LOG = max(_candidates, key=os.path.getmtime)
        else:
            RENDER_LOG = None
        if not RENDER_LOG:
            log("No fresh render log found (within 2h) — using empty context")
            render_log_content = ''
            raise FileNotFoundError("skip")
        log(f"Using render log: {RENDER_LOG}")
        with open(RENDER_LOG) as f:
            lines = f.readlines()
        keep = [l.strip() for l in lines if l.strip() and
                not any(x in l for x in ['urllib3', 'HTTP Request', 'DEBUG', 'WARNING: Retrying'])]
        render_log_content = '\n'.join(keep[-50:])
    except:
        render_log_content = 'Render log unavailable'

    # ── Extract episode title from script.json for grading ────────────
    episode_title = 'Not provided'
    try:
        import glob as _glob2
        _run_dir = os.path.dirname(LATEST)
        _script_candidates = (
            _glob2.glob(os.path.join(_run_dir, 'script.json')) +
            _glob2.glob(os.path.join(_run_dir, '..', 'script.json')) +
            _glob2.glob(os.path.join(OUTPUT_DIR, '*', 'script.json'))
        )
        _script_candidates = [f for f in _script_candidates if os.path.isfile(f)]
        if _script_candidates:
            _script_file = max(_script_candidates, key=os.path.getmtime)
            with open(_script_file) as _sf:
                _script_data = json.load(_sf)
            episode_title = _script_data.get('episode_title', 'Not provided')
            log(f"Episode title: {episode_title}")
        else:
            log("No script.json found — episode title unavailable")
    except Exception as _et_err:
        log(f"Episode title extraction failed: {_et_err}")

    # ── Upload video to Gemini Files API for two-pass grading ────────
    file_uri = upload_video_to_gemini(LATEST, GEMINI_KEY)
    if file_uri:
        log("Video upload successful — two-pass grading enabled")
    else:
        log("Video upload skipped — text-only grading (fallback)")

    # ── Build Gemini prompt ───────────────────────────────────────────
    log("Building Gemini grading prompt...")

    PROMPT = f"""You are the Chief Quality Officer for Protocol Pulse, a daily autonomous cypherpunk Bitcoin intelligence video show viewed through an Austrian economics lens.
PBX is the SOLE host. This is a single-host show — there is no co-host, no second voice, no guest expected. Do NOT penalise for the absence of a second host.
Your job: grade this episode with maximum rigour. Be brutally honest. A grade A means it is genuinely broadcast-ready and PBX will publish it immediately. Do not hand out A grades lightly.

=== EPISODE FORENSIC DATA ===

FILE: {os.path.basename(LATEST)}
EPISODE TITLE: {episode_title}
DURATION: {duration:.1f} seconds ({duration/60:.1f} minutes)
FILE SIZE: {filesize_mb:.1f} MB
BITRATE: {bit_rate_kbps} kbps
RESOLUTION: {width}x{height}
FRAMERATE: {fps} fps
VIDEO CODEC: {vcodec}
AUDIO CODEC: {acodec} | {sample_rate} Hz | {channels}
TOTAL STREAMS: {num_streams}

LOUDNESS (EBU R128):
  Integrated: {integrated_lufs} LUFS   (target: -16 to -14 LUFS)
  True Peak: {true_peak_dbfs} dBFS     (must be under -1.0 dBFS)
  LRA: {lra_lu} LU                     (target: 4-18 LU)

BLACK FRAME SEGMENTS: {black_count_total} total | {black_count_mid} mid-video
  (Mid-video blacks are critical failures. Start/end fades OK.)
  Details: {str(black_mid[:5]) if black_mid else 'none'}

SILENCE GAPS (>0.8s, mid-video): {silence_count}

FREEZE FRAMES (>1s): {freeze_count}

=== RENDER LOG (content/script details) ===
{render_log_content}

=== GRADING RUBRIC ===

Grade each dimension 1-10. Then calculate weighted overall score.

TECHNICAL QUALITY (40% weight):
1. duration_check: 480-900s ideal (8-15min). Under 180s = automatic F. 300-480s acceptable but short. Over 900s penalise.
2. resolution_check: 1920x1080 = 10. 1280x720 = 7. Anything else = fail.
3. framerate_check: 24-30fps = 10. Under 24fps = 5. Under 15fps = 0.
4. loudness_check: -16 to -14 LUFS = 10. -18 to -12 LUFS = 7. Outside -20 to -10 = critical failure (score 0).
5. true_peak_check: Under -1 dBFS = 10. -1 to 0 = 7. Over 0 dBFS = critical failure (clipping).
6. black_frames_check: 0 mid-video blacks = 10. 1 = 6. 2+ = critical failure (score 0).
7. silence_check: 0 gaps = 10. 1-2 gaps = 6. 3+ = major issue (score 3). NOTE: Dramatic pauses (under 4 seconds, intentional for emphasis after "..." in script) should NOT be penalized — only count genuine dead air gaps.
8. freeze_check: 0 freezes = 10. 1 = 5. 2+ = critical failure.
9. codec_check: h264/aac = 10. h265/aac = 10. Other combos = 5.
10. file_integrity_check: Clean container, both streams present, reasonable bitrate (500-5000 kbps) = 10.

CONTENT QUALITY (35% weight):
11. clip_relevance: Are clips from real Bitcoin news? Are the sources credible (not altcoin shills, not 24/7 loops)? Preston Pysh, Lyn Alden, Robert Breedlove, TFTC, and Simply Bitcoin rank editorially higher — clips from these sources are a positive signal. Austrian economics framing (sound money, Cantillon effect, time preference, proof-of-work ethos) is a positive editorial signal. Signal Active Nostr content (npubs, zaps, relay discussion) is a feature, not a bug — do not penalise.
12. script_quality: Is the narration between clips informed, specific, and adds value beyond just re-reading the clips?
13. cold_open_hook: Does the episode open with a compelling, specific hook that makes you want to keep watching?
14. narrative_arc: Does the episode flow logically from open -> clips -> analysis -> close? Or is it random?
15. host_authenticity: PBX is the SOLE host — score 10/10 if PBX voice is clean, natural, authoritative, and well-paced throughout. Do NOT penalise for absence of a second host or co-host. Only deduct for dead air, robotic tone, or missing audio in PBX's voice.
16. episode_title: Is the title specific and punchy? Not generic clickbait. Should reflect the actual main story.
17. no_filler: No ad reads, no sponsor segments, no off-topic content, no repeated clips.
18. timeliness: Is the content from today or yesterday? Not stale week-old news.

PRODUCTION QUALITY (25% weight):
19. music_mix: Background music present at proper level, not overpowering narration. Sidechain ducking working?
20. transitions: Are there clean glitch transitions between segments? No hard cuts mid-sentence.
21. visual_polish: Cyberpunk aesthetic consistent. Lower thirds present. No graphical glitches.
22. no_artifacts: No stuttering, no looping, no corrupted frames visible.
23. audio_quality: Narration clear, no clipping, no echo, no background noise in voiceover.
24. pacing: Does the episode feel tight? Not dragging? Not too rushed?

=== YOUR RESPONSE ===

You MUST respond ONLY with valid JSON. No preamble, no explanation, no markdown fences. Raw JSON only.

{{
  "grade": "A|B|C|D|F",
  "overall_score": 0-100,
  "broadcast_ready": true|false,
  "technical_score": 0-100,
  "content_score": 0-100,
  "production_score": 0-100,
  "dimensions": {{
    "duration_check": {{"score": 0-10, "note": "explain"}},
    "resolution_check": {{"score": 0-10, "note": "explain"}},
    "framerate_check": {{"score": 0-10, "note": "explain"}},
    "loudness_check": {{"score": 0-10, "note": "explain"}},
    "true_peak_check": {{"score": 0-10, "note": "explain"}},
    "black_frames_check": {{"score": 0-10, "note": "explain"}},
    "silence_check": {{"score": 0-10, "note": "explain"}},
    "freeze_check": {{"score": 0-10, "note": "explain"}},
    "codec_check": {{"score": 0-10, "note": "explain"}},
    "file_integrity_check": {{"score": 0-10, "note": "explain"}},
    "clip_relevance": {{"score": 0-10, "note": "explain"}},
    "script_quality": {{"score": 0-10, "note": "explain"}},
    "cold_open_hook": {{"score": 0-10, "note": "explain"}},
    "narrative_arc": {{"score": 0-10, "note": "explain"}},
    "host_authenticity": {{"score": 0-10, "note": "explain"}},
    "episode_title": {{"score": 0-10, "note": "explain"}},
    "no_filler": {{"score": 0-10, "note": "explain"}},
    "timeliness": {{"score": 0-10, "note": "explain"}},
    "music_mix": {{"score": 0-10, "note": "explain"}},
    "transitions": {{"score": 0-10, "note": "explain"}},
    "visual_polish": {{"score": 0-10, "note": "explain"}},
    "no_artifacts": {{"score": 0-10, "note": "explain"}},
    "audio_quality": {{"score": 0-10, "note": "explain"}},
    "pacing": {{"score": 0-10, "note": "explain"}}
  }},
  "critical_failures": [],
  "warnings": [],
  "strengths": [],
  "verdict": "One punchy sentence summarising the episode quality",
  "recommendation": "PUBLISH|FIX_AND_RERENDER|DO_NOT_PUBLISH"
}}

Grade thresholds:
- A: overall_score >= 88, zero critical_failures, broadcast_ready = true
- B: overall_score 75-87, at most 1 minor critical failure
- C: overall_score 60-74
- D: overall_score 40-59
- F: overall_score < 40 OR duration < 180s OR clipping OR 2+ mid-video black segments
Note: Episodes 8-15 minutes (480-900s) are the ideal target format. 5 clips is the target.
"""

    if file_uri:
        PROMPT = """You have been provided the actual video file to watch.
Score ALL dimensions based on what you actually see and hear.
Do NOT write 'Assumed' for any dimension — watch the video.
For host_authenticity: watch for lip sync quality, natural pacing,
eye blinks, head movement. Score based on actual observation.
For no_artifacts: watch for freeze frames, stuttering, compression
artifacts, black flashes. Score based on actual observation.
For visual_polish: observe the lower thirds, transitions, cyberpunk
aesthetic. Score based on actual observation.

""" + PROMPT

    # ── Call Gemini ───────────────────────────────────────────────────
    log("Calling Gemini 2.5 Pro for grading (this may take 30-60s)...")

    url = f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key={GEMINI_KEY}'
    if file_uri:
        parts_list = [
            {"file_data": {"mime_type": "video/mp4", "file_uri": file_uri}},
            {"text": PROMPT}
        ]
    else:
        parts_list = [{"text": PROMPT}]

    payload = {
        'contents': [{'parts': parts_list}],
        'generationConfig': {'maxOutputTokens': 8000, 'temperature': 0.05}
    }

    req_obj = urllib.request.Request(url,
        data=json.dumps(payload).encode(),
        headers={'Content-Type': 'application/json'})

    try:
        with urllib.request.urlopen(req_obj, timeout=180) as resp:
            d = json.loads(resp.read())
            parts = d['candidates'][0]['content'].get('parts', [])
            text = next((p['text'] for p in parts if 'text' in p), None)
            if not text:
                log("FATAL: Gemini returned no text")
                sys.exit(2)
    except urllib.error.HTTPError as e:
        log(f"FATAL: Gemini HTTP error {e.code}: {e.read().decode()[:200]}")
        sys.exit(2)
    except Exception as e:
        log(f"FATAL: Gemini call failed: {e}")
        sys.exit(2)

    # ── Parse result ──────────────────────────────────────────────────
    clean = text.strip()
    if '```json' in clean:
        clean = clean.split('```json')[1].split('```')[0].strip()
    elif '```' in clean:
        clean = clean.split('```')[1].split('```')[0].strip()

    # Fix trailing commas before } or ] (common Gemini output issue)
    clean = re.sub(r',\s*([}\]])', r'\1', clean)

    try:
        result = json.loads(clean)
    except json.JSONDecodeError as e:
        log(f"FATAL: Could not parse Gemini JSON: {e}")
        log(f"Raw response: {clean[:500]}")
        sys.exit(2)

    grade = result.get('grade', 'F')
    score = result.get('overall_score', 0)
    broadcast = result.get('broadcast_ready', False)
    recommendation = result.get('recommendation', 'DO_NOT_PUBLISH')
    verdict = result.get('verdict', '')
    critical = result.get('critical_failures', [])
    warnings = result.get('warnings', [])
    strengths = result.get('strengths', [])

    # Save full grade report
    os.makedirs(os.path.dirname(GRADE_FILE), exist_ok=True)
    with open(GRADE_FILE, 'w') as f:
        json.dump(result, f, indent=2)
    log(f"Grade report saved to {GRADE_FILE}")

    # Per-render grade history
    os.makedirs(GRADES_DIR, exist_ok=True)
    ts_tag = time.strftime('%Y%m%d_%H%M%S')
    per_render_path = os.path.join(GRADES_DIR, f'grade_{ts_tag}.json')
    with open(per_render_path, 'w') as f:
        json.dump(result, f, indent=2)
    log(f"Per-render grade saved to {per_render_path}")

    # ── Clean up uploaded file from Gemini ─────────────────────────────
    if file_uri:
        file_id = file_uri.split("/files/")[-1]
        del_url = f"https://generativelanguage.googleapis.com/v1beta/files/{file_id}?key={GEMINI_KEY}"
        try:
            del_req = urllib.request.Request(del_url, method="DELETE")
            urllib.request.urlopen(del_req, timeout=15)
            log(f"Cleaned up uploaded file: {file_id}")
        except Exception as e:
            log(f"File cleanup failed (non-fatal): {e}")

    # ── Print full scorecard ──────────────────────────────────────────
    log("=" * 60)
    log(f"GEMINI GRADE: {grade}  |  SCORE: {score}/100  |  {recommendation}")
    log(f"VERDICT: {verdict}")
    log(f"Technical: {result.get('technical_score')}/100  Content: {result.get('content_score')}/100  Production: {result.get('production_score')}/100")
    log("-" * 60)

    dims = result.get('dimensions', {})
    for dim, data in dims.items():
        s = data.get('score', '?')
        n = data.get('note', '')
        flag = '  ✓' if isinstance(s, int) and s >= 8 else ('  !' if isinstance(s, int) and s < 6 else '')
        log(f"  {dim:30s} {s}/10{flag}  {n[:80]}")

    log("-" * 60)
    if critical:
        log(f"CRITICAL FAILURES ({len(critical)}):")
        for c in critical:
            log(f"  !! {c}")
    if warnings:
        log(f"WARNINGS ({len(warnings)}):")
        for w in warnings:
            log(f"  -- {w}")
    if strengths:
        log(f"STRENGTHS ({len(strengths)}):")
        for s in strengths:
            log(f"  ++ {s}")
    log("=" * 60)

    # ── Record to episode memory ─────────────────────────────────────
    try:
        sys.path.insert(0, str(PIPELINE_DIR))
        from episode_memory import record_episode
        _render_id = os.path.basename(os.path.dirname(LATEST)) or os.path.basename(LATEST).replace('.mp4', '')
        _date = time.strftime('%Y-%m-%d')
        _clips_used = []
        _manifest_path = os.path.join(os.path.dirname(LATEST), 'episode_manifest.json')
        if os.path.exists(_manifest_path):
            with open(_manifest_path) as _mf:
                _manifest = json.load(_mf)
            for _seg in _manifest.get('segments', []):
                if _seg.get('type') == 'partner_clip':
                    _vpath = _seg.get('video_path', '')
                    _fname = os.path.basename(_vpath)
                    _parts = _fname.replace('.mp4', '').split('_', 2)
                    _clip_info = {'channel': _parts[2].rsplit('_', 1)[0] if len(_parts) > 2 else 'Unknown',
                                  'video_id': _parts[2].rsplit('_', 1)[-1] if len(_parts) > 2 else ''}
                    _clips_used.append(_clip_info)
        record_episode(_render_id, _date, result, _clips_used)
        log(f"Episode memory recorded: {_render_id} — grade {grade}, {len(_clips_used)} clips")
    except Exception as _em_err:
        log(f"[WARN] Episode memory recording failed: {_em_err}")

    # ── Pass/fail gate ────────────────────────────────────────────────
    if grade == 'A' and broadcast and score >= 88:
        log("*** GRADE A CONFIRMED — BROADCAST READY ***")
        with open(PASS_FILE, 'w') as f:
            f.write(f"GRADE A CONFIRMED\n")
            f.write(f"File: {LATEST}\n")
            f.write(f"Score: {score}/100\n")
            f.write(f"Verdict: {verdict}\n")
            f.write(f"Graded: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        print(f"\nGRADE_A_PASS|{score}|{LATEST}|{verdict}")
        sys.exit(0)
    else:
        log(f"NOT GRADE A: {grade} ({score}/100) — PBX will not be shown this render")
        print(f"\nGRADE_{grade}_FAIL|{score}|{LATEST}|{verdict}")
        sys.exit(1)


if __name__ == '__main__':
    main()
